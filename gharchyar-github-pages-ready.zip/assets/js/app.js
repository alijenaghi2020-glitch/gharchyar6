(() => {
  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(open));
      menuButton.setAttribute("aria-label", open ? "بستن فهرست" : "باز کردن فهرست");
    });
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      nav.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
    }));
  }

  const compost = document.getElementById("compost");
  const yieldInput = document.getElementById("yield");
  const result = document.getElementById("result");
  const note = document.getElementById("result-note");
  const calculate = document.getElementById("calculate");
  const formatter = new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 1 });

  function calculateYield() {
    const compostKg = Number(compost?.value);
    const yieldPerTon = Number(yieldInput?.value);
    if (!Number.isFinite(compostKg) || !Number.isFinite(yieldPerTon) || compostKg <= 0 || yieldPerTon <= 0) {
      result.textContent = "—";
      note.textContent = "لطفاً مقادیر مثبت و معتبر وارد کنید.";
      return;
    }
    const estimate = (compostKg / 1000) * yieldPerTon;
    result.innerHTML = `${formatter.format(estimate)} <small>کیلوگرم</small>`;
    note.textContent = "برآورد تقریبی؛ عملکرد واقعی ممکن است متفاوت باشد.";
  }
  calculate?.addEventListener("click", calculateYield);
  compost?.addEventListener("input", calculateYield);
  yieldInput?.addEventListener("input", calculateYield);
  calculateYield();

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();
})();
